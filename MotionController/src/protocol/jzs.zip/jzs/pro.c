#include "pro.h"


static int  cmd_buf[COMMUNICATION_MAX_LEN];
static int len = 0;
static int finalsum;

	 static int check_sum(int* pdat, int len)
	 {
	 	int i;
	 	int sum = 0;
	 	for (i = 0; i < len; i++)
	 		sum += pdat[i];

	 	return sum;
	 }


	 int  protocol( int ch,int*pdat)
{
   static int ptr = 0 ;
   static int flag = 0 ;
   switch(flag){
   case 0:
	   if(ch == 0x23){
		   flag = 1;
	   }
	   else
	   {
		   flag = 0;
	   }
	   break;
   case 1:
	   len = ch;
	   flag = 2;
	   break;
   case 2:

	   cmd_buf[ptr] = ch;
   	 ptr++ ;
     if (ptr >= len+1)
     {
    	 finalsum=check_sum(cmd_buf,len) ;
    	 if( cmd_buf[len]==finalsum)
    	 {
    		 memcpy(pdat, cmd_buf, len);
    		 flag = 0;
    		 ptr=0;
    	 }
    	 else
    	 {
    		 flag = 0;
    		 ptr=0;
    	 }
   	}

   	   break;

   default:
	   flag = 0;
	   break;

   }
   return ok;
   }
