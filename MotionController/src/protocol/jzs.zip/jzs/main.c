/*
 * main.c
 */


#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h"   // DSP2833x Examples Include File

//#include "../config.h"
//#include "protocol/protocol_analysis.h"
#include "pro.h"

//#pragma CODE_SECTION(ISRTimer0, "ramfuncs");

interrupt void spiTxFifoIsr(void);
interrupt void spiRxFifoIsr(void);
interrupt void ISRTimer0 (void);


void delay_loop(void);
void spi_fifo_init(void);

void error();
void configtestled (void);

#define	  LED1	GpioDataRegs.GPBDAT.bit.GPIO50
Uint16    *ExRamStart = (Uint16 *) 0x100000;
Uint16 sdata[8];     // Send data buffer
Uint16 rdata[8];     // Receive data buffer
Uint16 errcounter;
Uint16 rdata_point;  // Keep track of where we are
Uint16 a;

//extern Uint16 RamfuncsLoadStart;
//extern Uint16 RamfuncsLoadEnd;
//extern Uint16 RamfuncsRunStart;

Uint16 data ;
int  data_buf[COMMUNICATION_MAX_LEN];
void main1(void)
{


	// Step 1. Initialize System Control:
// PLL, WatchDog, enable Peripheral Clocks
// This example function is found in the DSP2833x_SysCtrl.c file.
   InitSysCtrl();

// Step 2. Initalize GPIO:
// This example function is found in the DSP2833x_Gpio.c file and
// illustrates how to set the GPIO to it's default state.
// InitGpio();  // Skipped for this example
//   InitXintf16Gpio();	//zq
   InitSpiaGpio();

// Step 3. Clear all interrupts and initialize PIE vector table:
// Disable CPU interrupts
   DINT;

// Initialize the PIE control registers to their default state.
// The default state is all PIE interrupts disabled and flags
// are cleared.
// This function is found in the DSP2833x_PieCtrl.c file.
   InitPieCtrl();

// Disable CPU interrupts and clear all CPU interrupt flags:
   IER = 0x0000;
   IFR = 0x0000;

//  PIE ������ָ��ָ���жϷ����(ISR)������ʼ��.
// ��ʹ�ڳ����ﲻ��Ҫʹ���жϹ��ܣ�ҲҪ�� PIE ���������г�ʼ��.
//  ��������Ϊ�˱���PIE����Ĵ���.
// The shell ISR routines are found in DSP2833x_DefaultIsr.c.
// This function is found in DSP2833x_PieVect.c.
   InitPieVectTable();

// Interrupts that are used in this example are re-mapped to
// ISR functions found within this file.
   EALLOW;  // This is needed to write to EALLOW protected registers
   PieVectTable.TINT0 = & ISRTimer0;
   PieVectTable.SPIRXINTA = &spiRxFifoIsr;
   PieVectTable.SPITXINTA = &spiTxFifoIsr;
   //PieVectTable.XINT13 = &cpu_timer1_isr;
   //PieVectTable.TINT2 = &cpu_timer2_isr;
   EDIS;    // This is needed to disable write to EALLOW protected registers
//   MemCopy(&RamfuncsLoadStart, &RamfuncsLoadEnd, &RamfuncsRunStart);
//   InitFlash();
// Step 4. Initialize the Device Peripheral. This function can be
//         found in DSP2833x_CpuTimers.c
   InitCpuTimers();   // For this example, only initialize the Cpu Timers

// Configure CPU-Timer 0, 1, and 2 to interrupt every second:
// 150MHz CPU Freq, 1 second Period (in uSeconds)
   spi_fifo_init();
   ConfigCpuTimer(&CpuTimer0, 150, 1000000);  //1s
   //ConfigCpuTimer(&CpuTimer1, 150, 1000000);
   //ConfigCpuTimer(&CpuTimer2, 150, 1000000);
	StartCpuTimer0();

// Enable CPU int1 which is connected to CPU-Timer 0, CPU int13
// which is connected to CPU-Timer 1, and CPU int 14, which is connected
// to CPU-Timer 2:
    IER |= M_INT1;
   //IER |= M_INT13;
   //IER |= M_INT14;

// Enable TINT0 in the PIE: Group 1 interrupt 7
    PieCtrlRegs.PIECTRL.bit.ENPIE = 1;
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;
	
// Enable global Interrupts and higher priority real-time debug events:
    EINT;   // ���ж� INTM ʹ��
    ERTM;   // ʹ����ʵʱ�ж� DBGM
    configtestled();
	LED1 = 0;

//	for(a=0; a<8; a++)
//	   {
//	     sdata[a] = a;
//	  }


	// Enable interrupts required for this example
	   PieCtrlRegs.PIECTRL.bit.ENPIE = 1;   // Enable the PIE block
	   PieCtrlRegs.PIEIER6.bit.INTx1 = 1;     // Enable PIE Group 6, INT 1
	   PieCtrlRegs.PIEIER6.bit.INTx2 = 1;     // Enable PIE Group 6, INT 2
	   IER = 0x20;                            // Enable CPU INT6
	   EINT;                                // Enable Global Interrupts

	  errcounter = 0;

/*	for(i = 0; i < 0xFFFF; i++)
	{
		*(ExRamStart + i) = i;
		if(*(ExRamStart + i) != i)
		{
			while(1);
		}
		if(*ExRamStart == 0x4000)
		 {
             while(1);
		 }
	}
*/
   for(;;)
     {


     }

}
void delay_loop()
{
    long      i;
    for (i = 0; i < 1000000; i++) {}
}
void error(void)
{
    errcounter++;
    asm("     ESTOP0");	 //Test failed!! Stop!
    for (;;);
}


void spi_fifo_init()
{
// Initialize SPI FIFO registers
   SpiaRegs.SPICCR.bit.SPISWRESET = 0; // Reset SPI

   SpiaRegs.SPICCR.all = 0x000F;       //16-bit character, Loopback mode
   SpiaRegs.SPICTL.all = 0x0013;       //Interrupt enabled, Master/Slave XMIT enabled
   SpiaRegs.SPISTS.all = 0x0000;
   SpiaRegs.SPIBRR = 0x0063;           // Baud rate
   SpiaRegs.SPIFFTX.all = 0xC028;      // Enable FIFO's, set TX FIFO level to 8
   SpiaRegs.SPIFFRX.all = 0x0028;      // Set RX FIFO level to 8
   SpiaRegs.SPIFFCT.all = 0x00;
   SpiaRegs.SPIPRI.all = 0x0010;

   SpiaRegs.SPICCR.bit.SPISWRESET = 1;  // Enable SPI

   SpiaRegs.SPIFFTX.bit.TXFIFO = 1;
   SpiaRegs.SPIFFRX.bit.RXFIFORESET = 1;
}

interrupt void spiTxFifoIsr(void)
{
 	Uint16 a;
    for(a = 0; a < 8; a++)
    {
 	   SpiaRegs.SPITXBUF = sdata[a];      // Send data
    }

    for(a = 0; a < 8; a++)                    // Increment data for next cycle
    {
 	   sdata[a]++;
    }


    SpiaRegs.SPIFFTX.bit.TXFFINTCLR = 1;  // Clear Interrupt flag
   PieCtrlRegs.PIEACK.all|= 0x20;  		// Issue PIE ACK
}

interrupt void spiRxFifoIsr(void)
{
  /* static Uint16 a = 0;
	int dat_buf[COMMUNICATION_MAX_LEN];


	int rtn = RTN_OK, dat_len = 0;

	data = SpiaRegs.SPIRXBUF;

	ch = data;
	if (analysis(ch) == RTN_OK) {
		rtn = get_cmd_buf(dat_buf, &dat_len, COMMUNICATION_MAX_LEN);
		if (rtn == RTN_OK) {
			command = dat_buf[0] ;
			mark = dat_buf[1] ;
			pos = dat_buf[2] ;
			time = dat_buf[6] ;
			period = dat_buf[7] ;
		}
	}
*/

	   int  rdat = ok;
	    data = SpiaRegs.SPIRXBUF;
	    rdat = protocol(data,data_buf);
	  if ( rdat == ok){

        data_buf[COMMUNICATION_MAX_LEN] ;


	  }






	SpiaRegs.SPIFFRX.bit.RXFFOVFCLR = 1;  // Clear Overflow flag
	SpiaRegs.SPIFFRX.bit.RXFFINTCLR = 1; 	// Clear Interrupt flag
	PieCtrlRegs.PIEACK.all|= 0x20;       // Issue PIE ack
}


interrupt void ISRTimer0(void)
{
    CpuTimer0.InterruptCount++;

   // Acknowledge this interrupt to receive more interrupts from group 1
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1; //0x0001����12���ж�ACKnowledge�Ĵ���������ȫ������������������ж�
    CpuTimer0Regs.TCR.bit.TIF = 1; // ��ʱ����ָ��ʱ�䣬��־λ��λ�������־
    CpuTimer0Regs.TCR.bit.TRB = 1;  // ����Timer0�Ķ�ʱ����

        LED1 = ~LED1;


}

void configtestled(void)
{
   EALLOW;
   GpioCtrlRegs.GPBMUX2.bit.GPIO50 = 0; // GPIO0 = GPIO0



   EDIS;
}

//===========================================================================
// No more.
//===========================================================================
