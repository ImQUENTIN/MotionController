#ifndef _PRO_H_
#define _PRO_H_


#define COMMUNICATION_MAX_LEN	1024
#define ok 0
typedef unsigned char byte;

int protocol(int ch,int*pdat );


#endif
